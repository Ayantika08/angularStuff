import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input() childFlag : boolean;

  constructor() { }

  ngOnInit() {
  }

  goToParent() {
    this.childFlag = false;
  }

  stayInChild() {
    this.childFlag = true;
  }

}
